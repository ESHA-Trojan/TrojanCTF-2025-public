function search(input){
    alert(input)
}